/*!
 * @license
 * 
 * dhtmlxGantt v.5.1.0 Stardard
 * This software is covered by GPL license. You also can obtain Commercial or Enterprise license to use it in non-GPL project - please contact sales@dhtmlx.com. Usage without proper license is prohibited.
 * 
 * (c) Dinamenta, UAB.
 * 
 */
!function(e){function t(n){if(a[n])return a[n].exports;var i=a[n]={i:n,l:!1,exports:{}};return e[n].call(i.exports,i,i.exports,t),i.l=!0,i.exports}var a={};t.m=e,t.c=a,t.d=function(e,a,n){t.o(e,a)||Object.defineProperty(e,a,{configurable:!1,enumerable:!0,get:n})},t.n=function(e){var a=e&&e.__esModule?function(){return e.default}:function(){return e};return t.d(a,"a",a),a},t.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},t.p="",t(t.s=60)}({60:function(e,t,a){e.exports=a(61)},61:function(e,t){gantt.locale={date:{month_full:["Ocak","Şubat","Mart","Nisan","Mayıs","Haziran","Temmuz","Ağustos","Eylül","Ekim","Kasım","Aralık"],month_short:["Oca","Şub","Mar","Nis","May","Haz","Tem","Ağu","Eyl","Eki","Kas","Ara"],day_full:["Pazar","Pazartesi","Salı","Çarşamba","Perşembe","Cuma","Cumartesi"],day_short:["Paz","Pzt","Sal","Çar","Per","Cum","Cmt"]},labels:{new_task:"Yeni görev",dhx_cal_today_button:"Bugün",day_tab:"Gün",week_tab:"Hafta",month_tab:"Ay",new_event:"Yeni etkinlik",icon_save:"Kaydet",icon_cancel:"İptal",icon_details:"Detaylar",icon_edit:"Düzenle",icon_delete:"Sil",confirm_closing:"",confirm_deleting:"Görev silinecek, emin misiniz?",section_description:"Açıklama",section_time:"Zaman Aralığı",section_type:"Tip",column_wbs:"WBS",column_text:"Görev Adı",column_start_date:"Başlangıç",column_duration:"Süre",column_add:"",link:"Bağlantı",confirm_link_deleting:"silinecek",link_start:" (başlangıç)",link_end:" (bitiş)",type_task:"Görev",type_project:"Proje",type_milestone:"Kilometretaşı",minutes:"Dakika",hours:"Saat",days:"Gün",weeks:"Hafta",months:"Ay",years:"Yıl",message_ok:"OK",message_cancel:"Ýptal"}}}});
//# sourceMappingURL=locale_tr.js.map